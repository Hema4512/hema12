# hema1427
Intelligence university admission
